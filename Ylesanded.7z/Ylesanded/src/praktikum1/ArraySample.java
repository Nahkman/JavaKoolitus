package praktikum1;

import java.util.ArrayList;

public class ArraySample {
	
	public static void main(String[] args) {
		
		int number = 3;
		
		//Collections on abiklass massiivide sorteerimiseks jms
		
		int[] numbers = {2, 3, 4, 5};
		int[] numbers2 = new int[10];
		// Massiividel tuleb alati määrata suurus. Massiivi pikkust ei saa muuta
		
		ArrayList<Integer> arvud3 = new ArrayList<>();
		arvud3.add(4);

	}
}
