package praktikum1;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JTextArea;


public class SaareInput {
	
	public static void main(String[] args) {
		
		JFrame aken = new JFrame();
        aken.setSize(300, 200);
        aken.setLayout(new GridLayout(2, 1));
        aken.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   
        
        JTextArea vali = new JTextArea();
        vali.setText("Tere!");
//        vali.setFont(new Font(Font.MONOSPACED, Font.ITALIC, 30));
        aken.add(vali);
        
        vali.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyTyped(KeyEvent e) {
        		e.setKeyChar('a');
        	}
        });
	}
}
